const form = document.querySelector('form');
const targetInput = document.getElementById('calories');

form.addEventListener('submit', onFormSubmit);
form.addEventListener('reset', onFormReset);

targetInput.addEventListener('focus', function(){
    if(this.value == '0'){
        this.value = '';
    }
});

function onFormSubmit(e){
    const calories = parseFloat(form.calories.value)
    if(isNaN(calories) <= 1200){
        alert("Please enter a valid target calories");
        return;
    }

    
}
